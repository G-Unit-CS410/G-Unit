import os
import json
import boto3
from datetime import datetime
import logging
import requests
from connect_to_rds import get_db_connection

region_name = "us-east-1"
logger = logging.getLogger()
logger.setLevel(logging.INFO)

secret_name = os.environ.get("SECRET_NAME")
client = boto3.client('secretsmanager')

try:
    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )
    
except Exception as e:
    logger.error("retrieving secret: %s", e)
    raise

secret_string = get_secret_value_response['SecretString']
secret_json = json.loads(secret_string)

os.environ['USERNAME'] = secret_json["username"]
os.environ['PASSWORD'] = secret_json["password"]

RECALL_API_URL = os.environ["RECALL_API_URL"]

def lambda_handler(event, context):
    qs = event.get("queryStringParameters") or {}
    make  = qs.get("make")
    model = qs.get("model")
    year  = qs.get("year")
    if not (make and model and year):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "make, model and year are required"})
        }

    try:
        conn   = get_db_connection()
        cursor = conn.cursor(dictionary=True)
    except Exception as e:
        logger.error("DB connect failed: %s", e)
        return {"statusCode": 500, "body": json.dumps({"error": "db connection failed"})}

    cursor.execute("""
        SELECT recall_count,
               rate_increase_percent,
               computed_at
          FROM vehicle_rate
         WHERE make=%s
           AND model=%s
           AND model_year=%s
         ORDER BY computed_at DESC
         LIMIT 1
    """, (make, model, year))
    existing = cursor.fetchone()
    if existing:
        cursor.close()
        conn.close()

        return {
            "statusCode": 200,
            "body": json.dumps({
                "make": make,
                "model": model,
                "year": year,
                "recall_count": existing["recall_count"],
                "rate_increase_percent": float(existing["rate_increase_percent"]),
                "computed_at": existing["computed_at"].isoformat()
            })
        }

    try:
        resp = requests.get(
            f"{RECALL_API_URL}?make={make}&model={model}&year={year}",
            timeout=10
        )
        resp.raise_for_status()
        recalls = resp.json().get("recalls", [])
    except Exception as e:
        logger.error("Recall fetch failed: %s", e)
        cursor.close(); conn.close()
        return {"statusCode": 502, "body": json.dumps({"error": "could not retrieve recalls"})}

    recall_count       = len(recalls)
    rate_increase_pct  = min(recall_count * 2, 20)

    try:
        cursor.execute("""
            INSERT INTO vehicle_rate
              (make, model, model_year, recall_count, rate_increase_percent)
            VALUES (%s, %s, %s, %s, %s)
        """, (make, model, year, recall_count, rate_increase_pct))
        conn.commit()
    except Exception as e:
        logger.error("Insert failed: %s", e)
        cursor.close(); conn.close()
        return {"statusCode": 500, "body": json.dumps({"error": "could not save rate"})}

    cursor.close()
    conn.close()
    return {
        "statusCode": 200,
        "body": json.dumps({
            "make": make,
            "model": model,
            "year": year,
            "recall_count": recall_count,
            "rate_increase_percent": rate_increase_pct,
            "computed_at": None
        })
    }
