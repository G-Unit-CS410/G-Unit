import json
import boto3
import os
import logging
from datetime import datetime
from connect_to_rds import get_db_connection

region_name = "us-east-1"
logger = logging.getLogger()
logger.setLevel(logging.INFO)

secret_name = os.environ.get("SECRET_NAME")
client = boto3.client('secretsmanager')

try:
    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )
    
except Exception as e:
    logger.error("retrieving secret: %s", e)
    raise

secret_string = get_secret_value_response['SecretString']
secret_json = json.loads(secret_string)

os.environ['USERNAME'] = secret_json["username"]
os.environ['PASSWORD'] = secret_json["password"]

def lambda_handler(event, context):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
    except Exception as e:
        logger.error("DB connect failed: %s", e)
        return {"statusCode": 500, "body": json.dumps({"error": "db connection failed"})}

    sql = """
    SELECT
      v.make_id,
      v.make_name,
      v.model_id,
      v.model_name,
      GROUP_CONCAT(vy.year ORDER BY vy.year ASC SEPARATOR ',') AS years
    FROM vehicle_models v
    LEFT JOIN vehicle_model_years vy
      ON v.make_id = vy.make_id
     AND v.model_id = vy.model_id
    GROUP BY
      v.make_id,
      v.make_name,
      v.model_id,
      v.model_name
    ORDER BY
      v.make_name,
      v.model_name
    """
    cursor.execute(sql)
    rows = cursor.fetchall()

    makes = {}
    for r in rows:
        mid = r["make_id"]
        if mid not in makes:
            makes[mid] = {
                "make_id": mid,
                "make_name": r["make_name"],
                "models": []
            }

        years = r["years"].split(",") if r["years"] else []
        makes[mid]["models"].append({
            "model_id":   r["model_id"],
            "model_name": r["model_name"],
            "years":      years
        })

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps(list(makes.values()))
    }
