import os
import mysql.connector


def get_db_connection():
    return mysql.connector.connect(
        host=os.environ.get("HOST"),
        database=os.environ.get("DATABASE"),
        user=os.environ['USERNAME'],
        password=os.environ['PASSWORD']
    )