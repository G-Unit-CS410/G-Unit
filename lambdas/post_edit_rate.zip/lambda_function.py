import os
import json
import boto3
from datetime import datetime
import logging
from connect_to_rds import get_db_connection

region_name = "us-east-1"
logger = logging.getLogger()
logger.setLevel(logging.INFO)

secret_name = os.environ.get("SECRET_NAME")
client = boto3.client('secretsmanager')

try:
    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )
    
except Exception as e:
    logger.error("retrieving secret: %s", e)
    raise

secret_string = get_secret_value_response['SecretString']
secret_json = json.loads(secret_string)

os.environ['USERNAME'] = secret_json["username"]
os.environ['PASSWORD'] = secret_json["password"]

def lambda_handler(event, context):
    qs = event.get("queryStringParameters") or {}
    make  = qs.get("make")
    model = qs.get("model")
    year  = qs.get("year")

    if not (make and model and year):
        return {
            "statusCode": 400,
            "body": json.dumps({
                "error": "Query parameters make, model and year are required"
            })
        }
    
    raw_body = event.get("body") or {}
    if isinstance(raw_body, str):
        try:
            body = json.loads(raw_body)
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Request body must be valid JSON"})
            }
    elif isinstance(raw_body, dict):
        body = raw_body
    else:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Request body must be a JSON object"})
        }

    new_rate = body.get("rate")
    if new_rate is None:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Request body must include numeric field 'rate'"})
        }
    try:
        new_rate = float(new_rate)
    except (TypeError, ValueError):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "'rate' must be a number"})
        }
        
    try:
        conn   = get_db_connection()
        cursor = conn.cursor()
    except Exception as e:
        logger.error("DB connection failed: %s", e)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Database connection failed"})
        }

    try:
        cursor.execute(
            """
            SELECT COUNT(*) 
              FROM vehicle_recall
             WHERE make = %s
               AND model = %s
               AND model_year = %s
            """,
            (make, model, year)
        )
        recall_count = cursor.fetchone()[0]
    except Exception as e:
        logger.error("Recall count query failed: %s", e)
        cursor.close()
        conn.close()
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Could not count recalls"})
        }

    try:
        cursor.execute(
            """
            INSERT INTO vehicle_rate
              (make, model, model_year, recall_count, rate_increase_percent)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (make, model, year, recall_count, new_rate)
        )
        conn.commit()
        rate_id = cursor.lastrowid
    except Exception as e:
        logger.error("Insert failed: %s", e)
        cursor.close()
        conn.close()
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Could not save new rate"})
        }

    try:
        cursor.execute(
            "SELECT computed_at FROM vehicle_rate WHERE id = %s",
            (rate_id,)
        )
        computed_at = cursor.fetchone()[0].strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logger.error("Fetch timestamp failed: %s", e)
        computed_at = None

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "id":                     rate_id,
            "make":                   make,
            "model":                  model,
            "model_year":             year,
            "recall_count":           recall_count,
            "rate_increase_percent":  new_rate,
            "computed_at":            computed_at
        })
    }