import os
import re
import xml.etree.ElementTree as ET
import logging
import zipfile
from io import BytesIO
from connect_to_rds import get_db_connection
import boto3

# * current ingest_parser logic

# configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# use /tmp for temporary file storage in lambda
DEFAULT_OUTPUT_PATH = '/tmp'

def download_zip_from_s3(bucket, key):
    """
        download the zip file from s3 and return a bytesIO object
        essential stores the file into memory for lambda to minimize disk writing to lambda
        
    """
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucket, Key=key)
    return BytesIO(response['Body'].read())

def unzip(zip_file_obj):
    """Unzips BytesIO to DEFAULT_OUTPUT_PATH which is /tmp \\
        
        zip_file_obj (BytesIO): zip file
    """    
    # extract all files from the zip into the default output path
    with zipfile.ZipFile(zip_file_obj, 'r') as z:
        z.extractall(DEFAULT_OUTPUT_PATH)

def extract_year(filename):
    """ extract a four-digit year from the filename using regex library 
        ex directory structure of the zip\\
        tmp\\
            ┣ dodge\\
            ┃ ┣ dodge2020.xml\\
            ┃ ┗ dodge2025.xml\\
            ┗ makes_subset.xml\\
        and it trys to get year if it is in file name
        by searching for exactly 4 digit that are 0-9 and returns string if matches 
    """ 
    m = re.search(r'(\d{4})', filename) 
    return m.group(1) if m else None

def parse_xml_file(filepath, year=None):
    """ parse an xml file and return a list of tuples
    (make_id, make_name, model_id, model_name, year)
    for easier row insertion in db
    
    """
    records = [] 
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
    except Exception as e:
        logger.exception("failed to parse xml %s: %s", filepath, e)
        return records

    results = root.find("Results")
    if results is None:
        logger.info("no results in %s", filepath)
        return records

    # if year no year in filename try to get year from search criteria in the xml file 
    if not year:
        search = root.find("SearchCriteria")
        if search is not None and search.text:
            m = re.search(r'ModelYear:(\d{4})', search.text)
            if m:
                year = m.group(1)

    for model in results.findall("MakeModels"):
        try:
            make_id = int(model.find("Make_ID").text)
            make_name = model.find("Make_Name").text
            model_id = int(model.find("Model_ID").text)
            model_name = model.find("Model_Name").text
            records.append((make_id, make_name, model_id, model_name, year))
        except Exception as e:
            logger.warning("skipping record in %s due to error: %s", filepath, e)
    return records

def aggregate_records():
    """
    traverse through the default output path to process every xml file;
    combine records so that each unique (make_id, model_id) includes a set of years.
    returns a dictionary with keys (make_id, model_id) and values (make_name, model_name, set_of_years)
    
    """
    aggregated = {}
    for root_dir, _, files in os.walk(DEFAULT_OUTPUT_PATH):
        for file in files:
            if file.endswith('.xml'):
                filepath = os.path.join(root_dir, file)
                year = extract_year(file)
                logger.info("processing %s (year: %s)", filepath, year)
                for rec in parse_xml_file(filepath, year):
                    key = (rec[0], rec[2])  # (make_id, model_id)
                    if key in aggregated:
                        aggregated[key][2].add(rec[4])
                    else:
                        aggregated[key] = (rec[1], rec[3], {rec[4]})
    return aggregated


def insert_into_db(aggregated):
    """
    insert aggregated records into two normalized tables:
    - vehicle_models: unique model info.
    - vehicle_model_years: available years for each model.
    """
    conn = get_db_connection()
    cur = conn.cursor()

    model_sql = """
    insert into vehicle_models (MAKE_ID, MAKE_NAME, MODEL_ID, MODEL_NAME)
    values (%s, %s, %s, %s)
    on duplicate key update make_name=values(make_name), model_name=values(model_name)
    """
    year_sql = """
    insert into vehicle_model_years (MAKE_ID, MODEL_ID, YEAR)
    values (%s, %s, %s)
    on duplicate key update year=values(year)
    """

    for (make_id, model_id), (make_name, model_name, years) in aggregated.items():
        cur.execute(model_sql, (make_id, make_name, model_id, model_name))
        for y in years:
            cur.execute(year_sql, (make_id, model_id, y))
    conn.commit()
    cur.close()
    conn.close()
    logger.info("inserted %d records", len(aggregated))