# Use this code snippet in your app.
# If you need more information about configurations
# or implementing the sample code, visit the AWS docs:
# https://aws.amazon.com/developer/language/python/

# * current deployed lambda

import boto3
import os
import json
import logging
import ingest_parse
import urllib.parse

region_name = "us-east-1"
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Get the secret name from an environment variable
secret_name = os.environ.get("SECRET_NAME")
# Create a Secrets Manager client
client = boto3.client('secretsmanager')

# Retrieve the secret value
try:
    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )
    
except Exception as e:
    logger.error("retrieving secret: %s", e)
    raise

# Decrypt the secret value
secret_string = get_secret_value_response['SecretString']
secret_json = json.loads(secret_string)
# Access the secret value
os.environ['USERNAME'] = secret_json["username"]
os.environ['PASSWORD'] = secret_json["password"]


def lambda_handler(event, context):
    """
    lambda handler function
    expects the event to include an s3 bucket and key for the zip file
    """
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
    
    if not bucket or not key:
        return {'statusCode': 400, 'body': "bucket and key required"}
    
    zip_file_obj = ingest_parse.download_zip_from_s3(bucket, key)
    ingest_parse.unzip(zip_file_obj)
    aggregated = ingest_parse.aggregate_records()
    ingest_parse.insert_into_db(aggregated)
    return {'statusCode': 200, 'body': f"inserted {len(aggregated)} unique vehicle models."}

