import json
import boto3
import os
import logging
import requests
from datetime import datetime
from connect_to_rds import get_db_connection

region_name = "us-east-1"
logger = logging.getLogger()
logger.setLevel(logging.INFO)

secret_name = os.environ.get("SECRET_NAME")
client = boto3.client('secretsmanager')

try:
    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )
    
except Exception as e:
    logger.error("retrieving secret: %s", e)
    raise

secret_string = get_secret_value_response['SecretString']
secret_json = json.loads(secret_string)

os.environ['USERNAME'] = secret_json["username"]
os.environ['PASSWORD'] = secret_json["password"]
def lambda_handler(event, context):
    qs = event.get("queryStringParameters") or {}
    make  = qs.get("make")
    model = qs.get("model")
    year  = qs.get("year")
    if not (make and model and year):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "make, model and year are required"})
        }

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
    except Exception as e:
        logger.error("DB connect error: %s", e)
        return {"statusCode": 500, "body": json.dumps({"error": "db connection failed"})}

    select_sql = """
        SELECT *
        FROM vehicle_recall
        WHERE make=%s AND model=%s AND model_year=%s
    """
    cursor.execute(select_sql, (make, model, year))
    recalls = cursor.fetchall()

    if not recalls:
        api_url = (
            f"https://api.nhtsa.gov/recalls/recallsByVehicle"
            f"?make={make}&model={model}&modelYear={year}"
        )
        try:
            r = requests.get(api_url, timeout=10)
            r.raise_for_status()
            results = r.json().get("results", [])
        except Exception as e:
            logger.error("NHTSA API error: %s", e)
            cursor.close()
            conn.close()
            return {
                "statusCode": 502,
                "body": json.dumps({"error": "external API failed", "details": str(e)})
            }

        insert_sql = """
            INSERT INTO vehicle_recall (
                manufacturer,
                nhtsa_campaign_number,
                park_it,
                park_outside,
                over_the_air_update,
                report_received_date,
                component,
                summary,
                consequence,
                remedy,
                notes,
                model_year,
                make,
                model
            ) VALUES (
                %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s
            )
        """
        for item in results:
            raw_date = item.get("ReportReceivedDate")
            logger.info(f"Raw ReportReceivedDate from API: {raw_date}")

            report_received_date = None
            if raw_date:
                for fmt in ("%d/%m/%Y", "%m/%d/%Y"):
                    try:
                        report_received_date = datetime.strptime(raw_date, fmt).date()
                        break
                    except ValueError:
                        continue

            cursor.execute(insert_sql, (
                item.get("Manufacturer"),
                item.get("NHTSACampaignNumber"),
                item.get("parkIt", False),
                item.get("parkOutSide", False),
                item.get("overTheAirUpdate", False),
                report_received_date,
                item.get("Component"),
                item.get("Summary"),
                item.get("Consequence"),
                item.get("Remedy"),
                item.get("Notes"),
                year,
                make,
                model
            ))
        conn.commit()

        cursor.execute(select_sql, (make, model, year))
        recalls = cursor.fetchall()

    cursor.close()
    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "make":    make,
            "model":   model,
            "year":    year,
            "recalls": recalls
        }, default=str)
    }
